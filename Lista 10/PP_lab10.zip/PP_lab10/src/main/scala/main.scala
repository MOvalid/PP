import Users.*
import Priorities.*

object main {

  def main(args: Array[String]): Unit = {
    val kot = new Kot // [Low, Low]
    val paniKrysia = new PaniKrysia // [Super, High]
    val zeus = new Zeus // [Super, Super]
    val terminal = new Terminal[Low, Super]("secret")

    terminal.read(kot)
//    terminal.write(kot)

    kot.secret

    terminal.read(paniKrysia)
//    terminal.write(paniKrysia)

    paniKrysia.secret

    terminal.read(zeus)
    terminal.write(zeus)

    zeus.secret

    val terminal2 = new Terminal[High, High]("secret2")

//    terminal2.read(kot)
//    terminal2.write(kot)

    kot.secret

    terminal2.read(paniKrysia)
    terminal2.write(paniKrysia)

    paniKrysia.secret

    terminal2.read(zeus)
    terminal2.write(zeus)

    zeus.secret
  }
}
