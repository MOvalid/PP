package Priorities

trait High extends Low {

}
