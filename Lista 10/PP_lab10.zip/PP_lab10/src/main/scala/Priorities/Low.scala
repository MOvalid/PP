package Priorities

trait Low {

}
