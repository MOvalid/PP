package Priorities

trait Super extends High{

}
