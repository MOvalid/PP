import Priorities.Low
import Users.User

class Terminal[-R <: Low, -W <: R](private var secret: String) {

  def write(user: User[_, W]): Unit = {
    secret = user.secret
  }

  def read(user: User[R, _]): Unit = {
    user.secret(secret)
  }
}
