package Users

import Priorities.Low

trait User[+READ <: Low, +WRITE <: Low]:
  def secret: String

  def secret(s: String): Unit
