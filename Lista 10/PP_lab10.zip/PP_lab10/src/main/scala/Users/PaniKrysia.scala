package Users

import Priorities.Super
import Priorities.High

class PaniKrysia extends User[Super, High]:
  private var secretString: String = "Może kawusi?"

  override def secret: String = secretString

  override def secret(s: String): Unit = secretString = secretString + " " + s