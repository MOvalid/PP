package Users

import Priorities.Low

class Kot extends User[Low, Low]:
  private var secretString: String = "MIAAAAAAAAU"

  override def secret: String = secretString

  override def secret(s: String): Unit = secretString = secretString + " " + s