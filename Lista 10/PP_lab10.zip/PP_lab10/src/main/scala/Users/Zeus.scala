package Users

import Priorities.Super

class Zeus extends User[Super, Super]:
  private var secretString: String = "*GROM Z JASNEGO NIEBA*"

  override def secret: String = secretString

  override def secret(s: String): Unit = secretString = secretString + " " + s
