package Details;

public enum Color {
    WHITE, BLACK, RED, BLUE, GREEN, YELLOW, ORANGE, GOLD, SILVER, VIOLET, PINK, CYAN;

    @Override
    public String toString() {
        return super.toString().toLowerCase();
    }
}
